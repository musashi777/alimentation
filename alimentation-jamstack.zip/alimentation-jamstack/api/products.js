/**
 * =============================================================================
 * API SERVERLESS - PRODUCTS.JS
 * =============================================================================
 * Cette fonction serverless Vercel sert d'intermédiaire entre le client
 * et Airtable. Elle récupère la liste des produits depuis la table 'Produits'
 * et les retourne au format JSON.
 * 
 * AVANTAGE DE SÉCURITÉ : Les clés API Airtable ne sont jamais exposées
 * côté client car cette fonction s'exécute côté serveur.
 * =============================================================================
 */

// Import de node-fetch pour faire des requêtes HTTP (Node.js < 18)
const fetch = require('node-fetch');

/**
 * Handler principal de la fonction serverless
 * @param {Object} req - Requête HTTP entrante
 * @param {Object} res - Réponse HTTP à retourner
 */
module.exports = async (req, res) => {
  
  // ===========================================================================
  // RÉCUPÉRATION DES VARIABLES D'ENVIRONNEMENT
  // Ces variables sont configurées dans l'interface Vercel (Settings > Environment Variables)
  // Elles ne sont jamais visibles dans le code client
  // ===========================================================================
  const AIRTABLE_API_KEY = process.env.AIRTABLE_API_KEY;    // Clé API personnelle Airtable
  const AIRTABLE_BASE_ID = process.env.AIRTABLE_BASE_ID;    // ID de la base de données
  const AIRTABLE_TABLE_NAME = 'Produits';                   // Nom de la table

  // ===========================================================================
  // VÉRIFICATION DE LA CONFIGURATION
  // ===========================================================================
  if (!AIRTABLE_API_KEY || !AIRTABLE_BASE_ID) {
    return res.status(500).json({ 
      error: 'Configuration Airtable manquante. Vérifiez les variables d\'environnement.' 
    });
  }

  // ===========================================================================
  // APPEL À L'API AIRTABLE
  // ===========================================================================
  try {
    // Construction de l'URL de l'API Airtable
    // encodeURIComponent pour gérer les caractères spéciaux dans le nom de table
    const airtableUrl = `https://api.airtable.com/v0/${AIRTABLE_BASE_ID}/${encodeURIComponent(AIRTABLE_TABLE_NAME)}?view=Grid%20view`;
    
    const response = await fetch(airtableUrl, {
      headers: {
        // Authentification Bearer avec la clé API
        Authorization: `Bearer ${AIRTABLE_API_KEY}`,
      },
    });

    // Vérification de la réponse Airtable
    if (!response.ok) {
      throw new Error(`Erreur Airtable: ${response.statusText}`);
    }

    // Récupération des données brutes
    const data = await response.json();
    
    // ===========================================================================
    // TRANSFORMATION DES DONNÉES
    // On transforme les données Airtable en format simplifié pour le client
    // ===========================================================================
    const products = data.records.map(record => ({
      id: record.id,                              // ID unique Airtable
      name: record.fields.Nom,                    // Nom du produit
      price: record.fields.Prix,                  // Prix unitaire
      description: record.fields.Description,     // Description
      image: record.fields.Image ? record.fields.Image[0].url : null, // URL de l'image
      category: record.fields.Categorie           // Catégorie
    }));

    // ===========================================================================
    // RÉPONSE AU CLIENT
    // Retourne la liste des produits au format JSON
    // ===========================================================================
    res.status(200).json(products);
    
  } catch (error) {
    // Gestion des erreurs
    console.error('Erreur API products:', error);
    res.status(500).json({ error: error.message });
  }
};
