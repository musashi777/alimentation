/**
 * =============================================================================
 * LOGIQUE CLIENT - MAIN.JS
 * =============================================================================
 * Ce fichier contient toute la logique JavaScript côté client pour le site
 * vitrine d'alimentation. Il gère :
 * - Le chargement des produits depuis l'API
 * - La gestion du panier avec une Map (complexité O(1))
 * - L'affichage dynamique des produits et du panier
 * - La soumission des commandes vers WhatsApp
 * =============================================================================
 */

// Attendre que le DOM soit complètement chargé avant d'exécuter le code
document.addEventListener('DOMContentLoaded', () => {
    
    /**
     * =========================================================================
     * ÉTAT DE L'APPLICATION
     * =========================================================================
     * L'objet state contient toutes les données de l'application :
     * - products : tableau des produits récupérés depuis Airtable
     * - cart : Map JavaScript pour stocker les articles du panier
     * 
     * Pourquoi une Map et pas un Array pour le panier ?
     * - Map offre une complexité O(1) pour get(), set(), has(), delete()
     * - Array nécessite une boucle O(n) pour trouver un élément
     * - Cela garantit une réactivité maximale même avec beaucoup d'articles
     * =========================================================================
     */
    const state = {
        products: [],           // Liste des produits depuis Airtable
        cart: new Map()         // Panier : clé = productId, valeur = {id, name, price, quantity}
    };

    /**
     * =========================================================================
     * SÉLECTEURS DOM
     * =========================================================================
     * On récupère une seule fois les éléments du DOM pour optimiser les perfs
     * =========================================================================
     */
    const productList = document.getElementById('product-list');
    const cartItems = document.getElementById('cart-items');
    const checkoutBtn = document.getElementById('checkout-btn');

    /**
     * =========================================================================
     * FONCTION : loadProducts()
     * =========================================================================
     * Charge les produits depuis la fonction serverless /api/products
     * Cette fonction appelle l'API Vercel qui elle-même interroge Airtable.
     * Les clés API restent sécurisées côté serveur.
     * =========================================================================
     */
    async function loadProducts() {
        try {
            // Appel à l'API serverless pour récupérer les produits
            const response = await fetch('/api/products');
            
            // Vérification de la réponse
            if (!response.ok) throw new Error('Erreur lors du chargement des produits');
            
            // Stockage des produits dans l'état
            state.products = await response.json();
            
            // Affichage des produits
            renderProducts();
        } catch (error) {
            // Gestion des erreurs
            console.error('Erreur loadProducts:', error);
            productList.innerHTML = '<p>Erreur lors du chargement des produits. Veuillez réessayer plus tard.</p>';
        }
    }

    /**
     * =========================================================================
     * FONCTION : renderProducts()
     * =========================================================================
     * Affiche la liste des produits dans le DOM.
     * Génère dynamiquement les cartes produit avec leurs boutons.
     * =========================================================================
     */
    function renderProducts() {
        // Message si aucun produit
        if (state.products.length === 0) {
            productList.innerHTML = '<p>Aucun produit disponible pour le moment.</p>';
            return;
        }

        // Génération HTML des cartes produit avec map() et join()
        productList.innerHTML = state.products.map(product => `
            <div class="product-card">
                <!-- Image du produit (si disponible) -->
                ${product.image ? `<img src="${product.image}" alt="${product.name}">` : ''}
                <div>
                    <!-- Nom du produit -->
                    <h3>${product.name}</h3>
                    <!-- Description -->
                    <p>${product.description || ''}</p>
                    <!-- Prix -->
                    <p class="price">${product.price}€</p>
                </div>
                <!-- Bouton d'ajout au panier - appelle addToCart() -->
                <button onclick="addToCart('${product.id}')">Ajouter au panier</button>
            </div>
        `).join('');
    }

    /**
     * =========================================================================
     * FONCTION : addToCart(productId)
     * =========================================================================
     * Ajoute un produit au panier ou incrémente sa quantité.
     * COMPLEXITÉ : O(1) grâce à l'utilisation de Map
     * 
     * @param {string} productId - L'identifiant du produit à ajouter
     * =========================================================================
     */
    // Exposée globalement pour être appelée depuis le HTML onclick
    window.addToCart = (productId) => {
        // Recherche du produit dans la liste (O(n) mais exécuté une seule fois)
        const product = state.products.find(p => p.id === productId);
        if (!product) return;  // Produit non trouvé = on arrête

        // Gestion du panier via Map (O(1) - temps constant)
        if (state.cart.has(productId)) {
            // Le produit existe déjà : on incrémente la quantité
            const item = state.cart.get(productId);
            item.quantity += 1;
        } else {
            // Nouveau produit : on l'ajoute à la Map
            state.cart.set(productId, {
                id: product.id,
                name: product.name,
                price: product.price,
                quantity: 1
            });
        }

        // Mise à jour de l'affichage du panier
        renderCart();
    };

    /**
     * =========================================================================
     * FONCTION : removeFromCart(productId)
     * =========================================================================
     * Supprime un produit du panier ou décrémente sa quantité.
     * COMPLEXITÉ : O(1) grâce à l'utilisation de Map
     * 
     * @param {string} productId - L'identifiant du produit à retirer
     * =========================================================================
     */
    // Exposée globalement pour être appelée depuis le HTML onclick
    window.removeFromCart = (productId) => {
        // Vérification si le produit est dans le panier (O(1))
        if (!state.cart.has(productId)) return;

        const item = state.cart.get(productId);
        
        if (item.quantity > 1) {
            // Quantité > 1 : on décrémente
            item.quantity -= 1;
        } else {
            // Quantité = 1 : on supprime l'article de la Map
            state.cart.delete(productId);
        }

        // Mise à jour de l'affichage du panier
        renderCart();
    };

    /**
     * =========================================================================
     * FONCTION : renderCart()
     * =========================================================================
     * Affiche le contenu du panier dans le DOM.
     * Calcule le total et met à jour l'état du bouton de commande.
     * =========================================================================
     */
    function renderCart() {
        // Panier vide
        if (state.cart.size === 0) {
            cartItems.innerHTML = '<p>Votre panier est vide.</p>';
            checkoutBtn.disabled = true;
            checkoutBtn.textContent = 'Votre panier est vide';
            return;
        }

        // Calcul du total et génération HTML
        let total = 0;
        let html = '<ul>';
        
        // Itération sur la Map (O(n) pour l'affichage, inévitable)
        state.cart.forEach((item, id) => {
            const subtotal = item.price * item.quantity;
            total += subtotal;
            html += `
                <li>
                    <span>${item.name} x${item.quantity}</span>
                    <div class="cart-controls">
                        <span>${subtotal.toFixed(2)}€</span>
                        <!-- Bouton - pour diminuer la quantité -->
                        <button onclick="removeFromCart('${id}')">-</button>
                        <!-- Bouton + pour augmenter la quantité -->
                        <button onclick="addToCart('${id}')">+</button>
                    </div>
                </li>
            `;
        });

        html += `</ul><p style="text-align: right; font-size: 1.2rem;"><strong>Total : ${total.toFixed(2)}€</strong></p>`;
        
        // Mise à jour du DOM
        cartItems.innerHTML = html;
        checkoutBtn.disabled = false;
        checkoutBtn.textContent = 'Passer la commande via WhatsApp';
        
        // Stockage du total pour la soumission
        state.total = total.toFixed(2);
    }

    /**
     * =========================================================================
     * ÉVÉNEMENT : Clic sur le bouton de commande
     * =========================================================================
     * Gère la soumission de la commande :
     * 1. Envoie les données à l'API serverless (/api/order)
     * 2. L'API enregistre la commande dans Airtable
     * 3. L'API génère l'URL WhatsApp avec le message
     * 4. Redirection vers WhatsApp
     * =========================================================================
     */
    checkoutBtn.addEventListener('click', async () => {
        // État de chargement
        checkoutBtn.disabled = true;
        checkoutBtn.textContent = 'Traitement en cours...';

        try {
            // Appel à l'API pour créer la commande
            const response = await fetch('/api/order', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    // Conversion de la Map en tableau pour le JSON
                    cart: Array.from(state.cart.values()),
                    total: state.total
                })
            });

            if (!response.ok) throw new Error('Erreur lors de la création de la commande');

            // Récupération de l'URL WhatsApp générée par le serveur
            const { whatsappUrl } = await response.json();
            
            // Redirection vers WhatsApp
            window.location.href = whatsappUrl;
        } catch (error) {
            // Gestion des erreurs
            alert('Une erreur est survenue lors de la commande. Veuillez réessayer.');
            console.error('Erreur checkout:', error);
            checkoutBtn.disabled = false;
            checkoutBtn.textContent = 'Passer la commande via WhatsApp';
        }
    });

    /**
     * =========================================================================
     * INITIALISATION
     * =========================================================================
     * Lance le chargement des produits au démarrage de l'application
     * =========================================================================
     */
    loadProducts();
});
